package org.techhub.springmvc.Repository;

import java.util.List;

import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Model.EventsModel;

public interface EventRepository 
{
   public boolean isAddEvents(EventsModel model);
   public int getDeptID(String deptname);
   public List<EventsModel>getAllEvents();
   public void isDeleteEventByID(int event_id);
   public boolean isupdate(EventsModel model);
   
}
