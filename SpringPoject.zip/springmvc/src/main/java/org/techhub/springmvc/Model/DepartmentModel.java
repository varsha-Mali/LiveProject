package org.techhub.springmvc.Model;

public class DepartmentModel {

	public int dept_id;
	public String Dept_Name;

	public int getDept_id() {
		return dept_id;
	}

	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}

	public String getDept_Name() {
		return Dept_Name;
	}

	public void setDept_Name(String dept_Name) {
		Dept_Name = dept_Name;
	}

	public String getDept_HOD() {
		return Dept_HOD;
	}

	public void setDept_HOD(String dept_HOD) {
		Dept_HOD = dept_HOD;
	}

	private String Dept_HOD;

	@Override
	public String toString() {
		return "DepartmentModel [dept_id=" + dept_id + ", Dept_Name=" + Dept_Name + ", Dept_HOD=" + Dept_HOD + "]";
	}

}
