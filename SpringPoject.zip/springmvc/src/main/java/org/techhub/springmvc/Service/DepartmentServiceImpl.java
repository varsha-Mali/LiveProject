package org.techhub.springmvc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Repository.DepartmentRepository;

@Service("deptService")
public class DepartmentServiceImpl implements DepartmentService
{
     @Autowired DepartmentRepository deptRepo;
	@Override
	public boolean isAddDepartment(DepartmentModel dept) 
	{
		
		return deptRepo.isAddDepartment(dept);
	}
	@Override
	public List<DepartmentModel> getAllDepartment() {
		
		return deptRepo.getAllDepartment();
	}
	@Override
	public void isDeleteDepartmentByID(int id)
	{
	   deptRepo.isDeleteDepartmentByID(id);
	}
	@Override
	public boolean isupdatebyid(DepartmentModel model) {
		
		return deptRepo.isupdatebyid(model);
	}
	@Override
	public boolean isDepartmentExists(String dept_Name) {
		
		return deptRepo.isDepartmentExists(dept_Name);
	}
	@Override
	public List<DepartmentModel> getAllDepartmentByCompName(String compName) {
		// TODO Auto-generated method stub
		return deptRepo.getAllDepartmentByCompName(compName);
	}
	

}
