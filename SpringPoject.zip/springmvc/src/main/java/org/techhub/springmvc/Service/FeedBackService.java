package org.techhub.springmvc.Service;

import java.util.List;

import org.techhub.springmvc.Model.FeedbackModel;

public interface FeedBackService 
{
	public boolean save(FeedbackModel feedback); 
	 public List<FeedbackModel> getAllFeedback();
}
