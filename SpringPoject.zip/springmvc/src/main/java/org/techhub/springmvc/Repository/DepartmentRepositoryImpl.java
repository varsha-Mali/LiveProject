package org.techhub.springmvc.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.springmvc.Model.DepartmentModel;
@Repository("deptRepo")
public class DepartmentRepositoryImpl implements DepartmentRepository {

	
	@Autowired JdbcTemplate template;
	
	
	List<DepartmentModel>list;
	@Override
	public boolean isAddDepartment(DepartmentModel dept) 
	{
		int value=template.update("insert into department values('0',?,?)", new PreparedStatementSetter()
				{
					@Override
					public void setValues(PreparedStatement ps) throws SQLException 
					{
						ps.setString(1, dept.getDept_Name());
						ps.setString(2, dept.getDept_HOD());
						
					}
			
			
				});
		return value>0?true:false;
	}
	@Override
	public List<DepartmentModel> getAllDepartment()
	{
		
		List<DepartmentModel>list=template.query("select * from department",  new RowMapper<DepartmentModel>()
				{

					@Override
					
					public DepartmentModel mapRow(ResultSet rs, int rowNum) throws SQLException {
					DepartmentModel deptmodel=new DepartmentModel();
					deptmodel.setDept_id(rs.getInt(1));
					deptmodel.setDept_Name(rs.getString(2));
					deptmodel.setDept_HOD(rs.getString(3));
					return deptmodel;
					}
			
				});
		
		return list.size()>0?list:null;
	}
	@Override
	public void isDeleteDepartmentByID(int id) 
	{
		template.update("delete from department where Dept_ID="+id);
		
	}
	@Override
	public boolean isupdatebyid(DepartmentModel model) {
		
		int value=template.update("update department set Dept_Name=?,Dept_HOD=? where Dept_ID=?", new PreparedStatementSetter()
				{

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						ps.setString(1,model.getDept_Name());
						ps.setString(2, model.getDept_HOD());
						ps.setInt(3, model.getDept_id());
						
					}
			       
				});
		
		
		return value>0?true:false;
	}
	@Override
	public boolean isDepartmentExists(String deptName) {
	    String sql = "SELECT COUNT(*) FROM department WHERE Dept_Name = ?";
	    Integer count = template.queryForObject(sql, new Object[]{deptName}, Integer.class);
	    return count != null && count > 0;
	}
	@Override
	public List<DepartmentModel> getAllDepartmentByCompName(String compName) {
		System.out.println("repo"+compName);
		list = template.query("select * from department where Dept_Name like '%"+compName+"%'",new RowMapper<DepartmentModel>() {

			@Override
			public DepartmentModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				DepartmentModel prm = new DepartmentModel();
			prm.setDept_id(rs.getInt(1));
			prm.setDept_Name(rs.getString(2));
            prm.setDept_HOD(rs.getString(3));
			return prm;
			}
	
		});
		return list.size()>0?list:null;
	}

}
