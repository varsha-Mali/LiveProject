package org.techhub.springmvc.Service;

import java.util.List;

import org.techhub.springmvc.Model.AluminModel;
import org.techhub.springmvc.Model.EventsModel;

public interface AluminService 
{
   public boolean isAddAlumin(AluminModel model);
   public int getDeptID(String deptname);
   public List<AluminModel> getAllAlumin();
   public void DeleteAlumin(int al_id);
   public boolean isUserLogin(String username,String password);
   public List<AluminModel> getAluminWithMinPassingYear();
   public List<EventsModel> findUpcomingEvents();
   public boolean updateprofile(AluminModel alumin);
   public AluminModel getAluminProfile(String userName);
   AluminModel getAluminById(Integer aluminId);
   boolean updateAlumin(AluminModel aluminModel);
public List<AluminModel> getAllCompanyByName(String name);
public List<AluminModel> getAllGender(String Gender);
public List<AluminModel> getAllYear(String year);
   
}
