package org.techhub.springmvc.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.springmvc.Model.AdminModel;
import org.techhub.springmvc.Repository.AdminRepository;

@Service("service")
public class AdminServiceImpl implements AdminService {
	@Autowired
	AdminRepository regRepo;

	@Override
	public boolean isValidate(AdminModel model) {
		
		return regRepo.isValidate(model);
	}

	@Override
	public AdminModel getAdminInfoByUsername(String username) {
		
		return regRepo.getAdminInfoByUsername(username);
	}

}
