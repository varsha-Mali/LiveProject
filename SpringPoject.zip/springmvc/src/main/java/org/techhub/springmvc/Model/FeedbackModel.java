package org.techhub.springmvc.Model;

public class FeedbackModel {

    private int feedback_id;
    private String eventName;
    private String aluminEmail;
    private String feedbackmsg;
	public int getFeedback_id() {
		return feedback_id;
	}
	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getAluminEmail() {
		return aluminEmail;
	}
	public void setAluminEmail(String aluminEmail) {
		this.aluminEmail = aluminEmail;
	}
	public String getFeedbackmsg() {
		return feedbackmsg;
	}
	public void setFeedbackmsg(String feedbackmsg) {
		this.feedbackmsg = feedbackmsg;
	}
}
