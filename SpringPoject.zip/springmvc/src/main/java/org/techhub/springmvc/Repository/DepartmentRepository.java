package org.techhub.springmvc.Repository;

import java.util.List;

import org.techhub.springmvc.Model.DepartmentModel;

public interface DepartmentRepository 
{
    public boolean isAddDepartment(DepartmentModel dept);
	public List<DepartmentModel> getAllDepartment();
	public void isDeleteDepartmentByID(int id);
	public boolean isupdatebyid(DepartmentModel model);
	public boolean isDepartmentExists(String dept_Name);
	public List<DepartmentModel> getAllDepartmentByCompName(String compName);
}
