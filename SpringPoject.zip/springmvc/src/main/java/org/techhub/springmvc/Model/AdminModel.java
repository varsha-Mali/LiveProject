package org.techhub.springmvc.Model;

public class AdminModel
{
	private int Login_ID;
     public int getLogin_ID() {
		return Login_ID;
	}
	public void setLogin_ID(int login_ID) {
		Login_ID = login_ID;
	}
	private String Username;
     private String Password;
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
     
}
