package org.techhub.springmvc.Repository;

import java.util.List;


import org.techhub.springmvc.Model.FeedbackModel;

public interface FeedbackRepository
{
	 public boolean save(FeedbackModel feedback); 
	 public List<FeedbackModel> getAllFeedback();
}
