package org.techhub.springmvc.Repository;

import org.techhub.springmvc.Model.AdminModel;

public interface AdminRepository
{
	public boolean isValidate(AdminModel model);
	public AdminModel getAdminInfoByUsername(String username);
}
