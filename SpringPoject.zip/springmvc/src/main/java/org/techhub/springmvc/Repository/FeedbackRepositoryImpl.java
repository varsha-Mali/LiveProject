package org.techhub.springmvc.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.springmvc.Model.FeedbackModel;

@Repository
public class FeedbackRepositoryImpl implements FeedbackRepository
{
	
	   @Autowired JdbcTemplate template;
	    public boolean save(FeedbackModel feedback) 
	    {
	        int value=template.update("insert into feedback values('0',?,?,?)",new PreparedStatementSetter() 
	        {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
				// ps.setInt(1,feedback.getFeedback_id());
	             ps.setString(1,feedback.getEventName());
	             ps.setString(2,feedback.getAluminEmail());
	             ps.setString(3,feedback.getFeedbackmsg());
	        
			} 
				
	    });
	        return value>0?true:false;
	        
	}
		@Override
		public List<FeedbackModel> getAllFeedback() {
			List<FeedbackModel>list=template.query("select * from feedback",new RowMapper<FeedbackModel>()
			{

				@Override
				public FeedbackModel mapRow(ResultSet rs, int rowNum) throws SQLException {
					FeedbackModel feed=new FeedbackModel();
					feed.setFeedback_id(rs.getInt(1));
					feed.setEventName(rs.getString(2));
					feed.setAluminEmail(rs.getString(3));
					feed.setFeedbackmsg(rs.getString(4));
					
					return feed;
				}
				
					
			
			});
			return list.size()>0?list:null;
		}
	

}
