package org.techhub.springmvc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.techhub.springmvc.Model.AdminModel;
import org.techhub.springmvc.Model.AluminModel;
import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Model.EventsModel;
import org.techhub.springmvc.Service.AluminService;
import org.techhub.springmvc.Service.DepartmentService;
import org.techhub.springmvc.Service.EventService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AluminController {
	@Autowired
	AluminService alservice;

	@RequestMapping("/Home")
	public String getPage() {
		return "AlumniHome";
	}

	@Autowired
	DepartmentService deptService;

	@RequestMapping(value = "/AddAlumin", method = RequestMethod.GET)
	public String AddAlumin(AluminModel model, Map map) {

		List<DepartmentModel> delist = deptService.getAllDepartment();
		map.put("delist", delist);
		return "Registration";
	}

	@RequestMapping(value = "/AluminAdd", method = RequestMethod.POST)
	public String processAddAluminForm(@RequestParam("Dept_Name") Integer Dept_Name,
			@RequestParam("first_name") String fName, @RequestParam("last_name") String lName,
			@RequestParam("address") String address, @RequestParam("company") String company,
			@RequestParam("gender") String gender, @RequestParam("passing_year") String passing,
			@RequestParam("email") String email, @RequestParam("userName") String username,
			@RequestParam("password") String password, Map<String, Object> map) {
		DepartmentModel departmentModel = new DepartmentModel();
		departmentModel.setDept_id(Dept_Name);

		AluminModel aluminModel = new AluminModel();
		aluminModel.setModel(departmentModel);
		System.out.println(Dept_Name);
		aluminModel.setFirst_name(fName);
		aluminModel.setLast_name(lName);
		aluminModel.setAddress(address);
		aluminModel.setCompany(company);
		aluminModel.setGender(gender);
		aluminModel.setPassing_year(passing);
		aluminModel.setEmail(email);
		aluminModel.setUserName(username);
		aluminModel.setPassword(password);
		List<DepartmentModel> delist = deptService.getAllDepartment();
		map.put("delist", delist);
		boolean b = alservice.isAddAlumin(aluminModel);
		System.out.println(b);
		if (b) {
			map.put("msg", "Alumni Added Successfully..");
		} else {
			map.put("msg", "Alumni Not Added");
		}
		return "Registration";
	}

	@RequestMapping(value = "/Alumin", method = RequestMethod.GET)
	public String CallAluminPage() {
		return "AluminLogin";
	}

	@RequestMapping(value = "/View", method = RequestMethod.GET)
	public String viewAlumin(AluminModel model, Map map) {
		List<AluminModel> alumnis = alservice.getAllAlumin();
		map.put("alumnis", alumnis);
		return "viewAlumin";
	}

	@RequestMapping(value = "/alumnidelete", method = RequestMethod.GET)
	public String Delete(@RequestParam("al_id") Integer al_id, Map map) {
		alservice.DeleteAlumin(al_id);
		List<AluminModel> alumnis = alservice.getAllAlumin();
		map.put("alumnis", alumnis);
		return "viewAlumin";
	}
	
	@RequestMapping(value="/AluminDash",method=RequestMethod.GET)
	   public String callDashBoard(@RequestParam("userName")String userName,@RequestParam("password")String password,HttpSession session,Map map)
		{
	    	
	    	boolean b=alservice.isUserLogin(userName,password);
	    	System.out.println(b);    	
	    	if(b)
	   	{
	    	session.setAttribute("user",userName);	
	   		map.put("msg","User Login SuccessFully...");
	   		return "AluminDashBoard";
	   	}
	  	else
	  	{
	   		map.put("msg","User Login Failed");
	   		return "AluminLogin";
	  	}
		} 	

	 
		  
		  

	@RequestMapping("/viewProfile")
	public String alumniProfile(HttpSession session, Map map) {
		String userName = (String) session.getAttribute("user");
		if (userName != null) {
			AluminModel model = alservice.getAluminProfile(userName);
			System.out.println(model);
			if (model != null) {
				map.put("alModel", model);
				return "viewProfile";
			} else {
				map.put("msg", "alumin not found");
				return "error";
			}
		} else {
			map.put("msg", "Please log in first");
			return "AluminLogin";
		}
	}

	@RequestMapping(value = "/min-passing-year", method = RequestMethod.GET)
	public String getAluminWithMinPassingYear(AluminModel model, Map map) {
		List<AluminModel> aluminList = alservice.getAluminWithMinPassingYear();
		map.put("aluminList", aluminList);
		return "aluminMinPassingYear"; // JSP page to display the alumni list
	}

	@RequestMapping("/upcoming-events")
	public String showUpcomingEvents(EventsModel model, Map map) {
		List<EventsModel> eventsList = alservice.findUpcomingEvents();
		System.out.println(eventsList);
		map.put("EventList", eventsList);
		return "UpcomingEvent"; // your JSP page name
	}

	@RequestMapping(value = "/viewComapnywiseAlumni", method = RequestMethod.GET)
	public String CompanywiseAlumin(Map<String, Object> map) {
		List<AluminModel> alumnis = alservice.getAllAlumin();
		map.put("alumnis", alumnis);
		return "CompanywiseAlumni";
	}
	
	
	
	@RequestMapping(value="/CallsearchByCompName", method = RequestMethod.GET)
	public String searchByCompanyNameURL(@RequestParam("n") String name, Map map) {
		System.out.println(name);// print 13
		List<AluminModel> list = alservice.getAllCompanyByName(name);
		System.out.println(list);

		if(list!=null)
        {
			map.put("alumnis", list);
        }
        else
        {
        	map.put("msg","This Company Not Available In Database !");
        }
	    
		
		return "compnybyname";
	}

	@RequestMapping(value = "/viewGenderwiseAlumni", method = RequestMethod.GET)
	public String viewGenderWiseAlumin(Map<String, Object> map) {
		List<AluminModel> alumnis = alservice.getAllAlumin();
		map.put("alumnis", alumnis);
		return "GenderwiseAlumni";
	}

	
	
	@RequestMapping(value="/searchByGender", method = RequestMethod.GET)
	public String searchByGenderURL(@RequestParam("n") String name, Map map) {
		System.out.println(name);// print 13
		List<AluminModel> list = alservice.getAllGender(name);
		System.out.println(list);		
		if(list!=null)
        {
			map.put("alumnis", list);
        }
        else
        {
        	map.put("msg","This Company Not Available In Database !");
        }
	    
		
		return "searchGender";
	}
	
	@RequestMapping(value = "/viewYearwiseAlumni", method = RequestMethod.GET)
	public String viewYearwiseAlumin(Map<String, Object> map) {
		List<AluminModel> alumnis = alservice.getAllAlumin();
		map.put("alumnis", alumnis);
		return "YearwiseAlumni";
	}
	
	@RequestMapping(value="/searchByYear", method = RequestMethod.GET)
	public String searchByYearURL(@RequestParam("year") String year, Map map) {
		System.out.println(year);// print 13
		List<AluminModel> list = alservice.getAllYear(year);
		System.out.println(list);
		if(list!=null)
        {
			map.put("alumnis", list);
        }
        else
        {
        	map.put("msg","This Company Not Available In Database !");
        }
	    
		
		return "searchGender";
	}	
	
	
	
	@RequestMapping(value = "/updateProfile", method = RequestMethod.GET)
	public String showUpdateForm(HttpSession session, Map<String, Object> map) 
	{
		AluminModel loggedInAlumin = (AluminModel) session.getAttribute("loggedInAlumin");
		map.put("alumin", loggedInAlumin);
		return "updateProfile"; // The JSP page for updating the profile
	}

	@RequestMapping(value = "/UpdateAlumin", method = RequestMethod.POST)
	public String updateAluminProfile(
			@RequestParam("first_name") String fName, @RequestParam("last_name") String lName,
			@RequestParam("address") String address, @RequestParam("company") String company,
			@RequestParam("gender") String gender, @RequestParam("passing_year") String passing,
			@RequestParam("email") String email, @RequestParam("userName") String username,
			@RequestParam("password") String password, Map<String, Object> map) {
		// Fetch the existing alumni record
		AluminModel aluminModel=new AluminModel(); // Assuming this method exists

		// Update alumni details
		aluminModel.setFirst_name(fName);
		aluminModel.setLast_name(lName);
		aluminModel.setAddress(address);
		aluminModel.setCompany(company);
		aluminModel.setGender(gender);
		aluminModel.setPassing_year(passing);
		aluminModel.setEmail(email);
		aluminModel.setUserName(username);
		aluminModel.setPassword(password);

		// Save updated alumni
		boolean isUpdated = alservice.updateAlumin(aluminModel); // Assuming this method exists

		if (isUpdated) {
			map.put("msg", "Alumni profile updated successfully.");
		} else {
			map.put("msg", "Failed to update profile.");
		}

		return "updateProfile"; // The JSP page showing the update result
	}
	
	
	

}
