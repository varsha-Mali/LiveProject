package org.techhub.springmvc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.springmvc.Model.FeedbackModel;
import org.techhub.springmvc.Repository.FeedbackRepository;

@Service
public class FeedBackServiceImpl implements FeedBackService
{
	    @Autowired
	    FeedbackRepository feedbackRepository;

		@Override
		public boolean save(FeedbackModel feedback) {
			
			return feedbackRepository.save(feedback);
		}

		@Override
		public List<FeedbackModel> getAllFeedback() {
			
			return feedbackRepository.getAllFeedback();
		}

	    
}


