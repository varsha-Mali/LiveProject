package org.techhub.springmvc.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Model.EventsModel;

@Repository("EventRepo")
public class EventRepositoryImpl implements EventRepository {
	@Autowired
	JdbcTemplate template;

	@Override
	public boolean isAddEvents(EventsModel model) {
		int value = template.update(
				"INSERT INTO events(Event_Name, date, Dept_ID, Event_Location, Event_Time) VALUES (?, ?, ?, ?, ?)",
				new PreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						ps.setString(1, model.getEvent_Name());
						ps.setString(2, model.getDate());
						ps.setInt(3, model.getDmodel().getDept_id());
						ps.setString(4, model.getEvent_location());
						ps.setString(5, model.getTime()); // Store time here
					}
				});
		return value > 0;
	}

	@Override
	public int getDeptID(String deptname) {
		try {
			Integer deptId = template.queryForObject("select Dept_ID from department where Dept_Name=?",
					new Object[] { deptname }, Integer.class);
			return deptId != null ? deptId : 0;
		} catch (Exception ex) {
			System.out.println("Error is:" + ex);
			return -1;
		}

	}

	@Override
	public List<EventsModel> getAllEvents() {

		List<EventsModel> listevents = template.query("select * from events", new RowMapper<EventsModel>() {

			@Override
			public EventsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				EventsModel emodel = new EventsModel();
				emodel.setEvent_ID(rs.getInt(1));
				emodel.setEvent_Name(rs.getString(2));
				emodel.setDate(rs.getString(3));
				emodel.setEvent_location(rs.getString(5));
				emodel.setTime(rs.getString(6));

				// Assuming DepartmentModel has a setDept_Name() method
				DepartmentModel dmodel = new DepartmentModel();
				dmodel.setDept_Name(rs.getString(4)); // Set department name
				emodel.setDmodel(dmodel); // Set the department model to events model

				return emodel;
			}
		});

		return listevents.size() > 0 ? listevents : null;
	}

	@Override
	public void isDeleteEventByID(int event_id) {

		template.update("delete from events where Event_ID=" + event_id);

	}

	@Override
	public boolean isupdate(EventsModel model) {
		System.out.println("repo"+model);
 		System.out.println("Repository Event" + "\t" + model);
		int value = template.update(
				"UPDATE events SET Event_Name =?, date =?, Dept_ID =?, Event_Location =?, Event_Time =? WHERE Event_ID = ?",
				new PreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						ps.setString(1, model.getEvent_Name());
						ps.setString(2, model.getDate());
						ps.setInt(3, model.getDdid()); // Set the department ID
						ps.setString(4, model.getEvent_location());
						ps.setString(5, model.getTime());
						ps.setInt(6, model.getEvent_ID()); // Set the Event_ID for the WHERE clause
					}
				});

		return value > 0 ? true : false;
	}

}
