package org.techhub.springmvc.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.springmvc.Model.AdminModel;
import org.techhub.springmvc.Model.AluminModel;
import org.techhub.springmvc.Model.EventsModel;
import org.techhub.springmvc.Repository.AluminRepository;
@Service("AluminServ")
public class AluminServiceImpl implements AluminService
{
    @ Autowired AluminRepository AluminRepo;
	@Override
	public boolean isAddAlumin(AluminModel model) {
		
		return AluminRepo.isAddAlumin(model);
	}
	@Override
	public int getDeptID(String deptname) {
		
		return AluminRepo.getDeptID(deptname); 
	}
	public List<AluminModel> getAllAlumin() {
        return AluminRepo.getAllAlumin();
	}
	@Override
	public void DeleteAlumin(int al_id) 
	{
		AluminRepo.DeleteAlumin(al_id);	
	}
	@Override
	public List<AluminModel> getAluminWithMinPassingYear()
	{
		return AluminRepo.getAluminWithMinPassingYear();
	}
	@Override
	public List<EventsModel> findUpcomingEvents() {
		
		return AluminRepo.findUpcomingEvents();
	}
	@Override
	public AluminModel getAluminProfile(String userName) {
		
		return AluminRepo.getAluminProfile(userName);
	}
	@Override
	public AluminModel getAluminById(Integer aluminId) {
		
		return AluminRepo.getAluminById(aluminId);
		
	}
	@Override
	public boolean updateAlumin(AluminModel aluminModel) {
		
		return AluminRepo.updateAlumin(aluminModel);
	}
	@Override
	public boolean updateprofile(AluminModel alumin) {
		return AluminRepo.updateprofile(alumin);
		
	}
	@Override
	public List<AluminModel> getAllCompanyByName(String name) {
		
		return AluminRepo. getAllCompanyByName(name);
	}
	@Override
	public List<AluminModel> getAllGender(String gender) {
		
		return AluminRepo.getAllGender(gender);
	}
	@Override
	public List<AluminModel> getAllYear(String year) {
		
		return AluminRepo.getAllYear(year);
	}
	@Override
	public boolean isUserLogin(String username, String password) {
		
		return AluminRepo.isUserLogin(username, password);
	}

}
	      
	

