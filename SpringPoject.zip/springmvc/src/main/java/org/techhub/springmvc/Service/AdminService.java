package org.techhub.springmvc.Service;

import org.techhub.springmvc.Model.AdminModel;

public interface AdminService 
{
	public boolean isValidate(AdminModel model);

	public AdminModel getAdminInfoByUsername(String username);
}
