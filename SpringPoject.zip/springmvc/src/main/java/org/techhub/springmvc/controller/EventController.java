package org.techhub.springmvc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Model.EventsModel;
import org.techhub.springmvc.Service.DepartmentService;
import org.techhub.springmvc.Service.EventService;

@Controller
public class EventController {
	@Autowired
	EventService EventServ;
	@Autowired
	DepartmentService deptService;


	@RequestMapping(value = "/AddEvent", method = RequestMethod.GET)
	public String showAddEventForm(Map<String, Object> map) {
		return "AddEvent";
	}

	@RequestMapping(value = "/addEvent", method = RequestMethod.POST)
	public String processAddEventsForm(@RequestParam("dept_name") String dname,
			@RequestParam("Event_Name") String eventName, @RequestParam("date") String date,
			@RequestParam("time") String time, @RequestParam("Event_location") String eventLocation, EventsModel model,
			Map<String, Object> map) {

		DepartmentModel dmodel = new DepartmentModel();
		int dept_id = EventServ.getDeptID(dname);
		dmodel.setDept_id(dept_id);

		// Set the model fields
		model.setDmodel(dmodel);
		model.setEvent_Name(eventName);
		model.setDate(date);
		model.setTime(time);
		model.setEvent_location(eventLocation);

		boolean b = EventServ.isAddEvents(model);
		if (b) {
			map.put("msg", "Events Added Successfully.");
		} else {
			map.put("msg", "Events Not Added");
		}
		return "AddEvent";
	}

	public List<EventsModel> getAllEvents() {
		List<EventsModel> list = EventServ.getAllEvents();

		System.out.println(list);
		return list;
	}

	@RequestMapping(value = "/viewEvent", method = RequestMethod.GET)
	public String viewAllDepartments(Map<String, Object> map) {
		List<EventsModel> list = EventServ.getAllEvents();
		map.put("Eventlist", list);
		return "ViewEvents";
	}

	@RequestMapping("/DeleteById")
	public String deleteEventByID(@RequestParam("Event_id") Integer Event_id, Map map) {
		EventServ.isDeleteEventByID(Event_id);
		map.put("Eventlist", this.getAllEvents());
		return "ViewEvents";
	}

	@RequestMapping("/updateevent")
	public String Updatepage(@RequestParam("Event_ID") Integer Event_ID, @RequestParam("Event_Name") String Event_Name,
			@RequestParam("Event_location") String Event_location, @RequestParam("date") String date,
			@RequestParam("Time") String Time, @RequestParam("Dept_Name") String Dept_Name, Map map) {
	List<DepartmentModel> d=deptService.getAllDepartment();
	/*
	 * for(DepartmentModel d1:d) { System.out.println(d1); }
	 */
	System.out.println(Event_location);
		map.put("id", Event_ID);
		map.put("name", Event_Name);
		map.put("location", Event_location);
		map.put(" date", date);
		map.put(" time", Time);
		map.put("dept",d);
		
		return "UpdateEvent";
		
		
	}
	@RequestMapping(value="/updateEventbyID",method = RequestMethod.POST)
	public String updateEv(EventsModel model, Map map) {
		System.out.println(model);

		boolean b = EventServ.isupdate(model);
		List<EventsModel> list = EventServ.getAllEvents();
		map.put("Eventlist", list);
		return "ViewEvents";
	}
}
