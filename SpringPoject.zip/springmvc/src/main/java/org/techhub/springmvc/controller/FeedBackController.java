package org.techhub.springmvc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.techhub.springmvc.Model.EventsModel;
import org.techhub.springmvc.Model.FeedbackModel;
import org.techhub.springmvc.Service.EventService;
import org.techhub.springmvc.Service.FeedBackService;

@Controller
public class FeedBackController
{

	    @Autowired
	    FeedBackService feedbackService;
	    
	    @Autowired
		EventService EventServ;
	    
	    @RequestMapping(value="/feedbackadd",method=RequestMethod.GET)
	    public String callFeedbackPage(Map map) {
	        List<EventsModel> list = EventServ.getAllEvents();
	        map.put("eventlist", list);
	        return "Feedback";  // Should map to Feedback.jsp
	    }

	    @RequestMapping(value="/AddFeedback", method=RequestMethod.GET)
	    public String giveFeedback(FeedbackModel model, Map map) {
	        boolean b = feedbackService.save(model);
	        if (b) {
	            map.put("msg", "Feedback Added successfully.");
	        } else {
	            map.put("msg", "Feedback not added.");
	        }
	        return "Feedback";  // Should map to Feedback.jsp
	    }

	    @RequestMapping(value="/FeedbackView",method=RequestMethod.GET)
	    public String viewFeedback(Map map) {
	        List<FeedbackModel> list = feedbackService.getAllFeedback();
	        map.put("feedbacklist", list);
	        return "viewFeedback";  // Should map to viewFeedback.jsp
	    }

	}


