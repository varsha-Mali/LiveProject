package org.techhub.springmvc.Model;

public class AluminModel extends DepartmentModel{
	private int alumin_id;
	private String first_name;
	private String last_name;
	private String email;
	private String address;
	private String company;
	private String userName;
	private String password;
	private String passing_year;
	private String gender;
	private DepartmentModel model; // Assuming this is needed
    private int dept;
	public int getAlumin_id() {
		return alumin_id;
	}

	public void setAlumin_id(int alumin_id) {
		this.alumin_id = alumin_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassing_year() {
		return passing_year;
	}

	public void setPassing_year(String passing_year) {
		this.passing_year = passing_year;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public DepartmentModel getModel() {
		return model;
	}

	public void setModel(DepartmentModel model) {
		this.model = model;
	}

	public int getDept() {
		return dept;
	}

	public void setDept(int dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "AluminModel [alumin_id=" + alumin_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", email=" + email + ", address=" + address + ", company=" + company + ", userName=" + userName
				+ ", password=" + password + ", passing_year=" + passing_year + ", gender=" + gender + ", model="
				+ model + ", dept=" + dept + "]";
	}

	

}
