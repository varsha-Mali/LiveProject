package org.techhub.springmvc.Repository;

import java.util.List;
import java.util.Optional;

import org.techhub.springmvc.Model.AdminModel;
import org.techhub.springmvc.Model.AluminModel;
import org.techhub.springmvc.Model.EventsModel;

public interface AluminRepository
{
  public boolean isAddAlumin(AluminModel model);

  public int getDeptID(String deptname);
  public List<AluminModel>getAllAlumin();
  public void DeleteAlumin(int al_id);
  public boolean isUserLogin(String username,String password);
  public List<AluminModel> getAluminWithMinPassingYear();
  public List<EventsModel> findUpcomingEvents();
  public boolean updateprofile(AluminModel alumin);
  AluminModel getAluminById(Integer aluminId); 
  boolean updateAlumin(AluminModel aluminModel); 
  public AluminModel getAluminProfile(String userName);
  public List<AluminModel> getAllCompanyByName(String name);
  public List<AluminModel> getAllGender(String gender);
  public List<AluminModel> getAllYear(String year);
}