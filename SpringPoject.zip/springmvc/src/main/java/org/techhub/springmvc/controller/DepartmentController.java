package org.techhub.springmvc.controller;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Service.DepartmentService;
import java.util.List;

@Controller
public class DepartmentController {

	@Autowired
	DepartmentService deptService;

	@RequestMapping(value = "/Add", method = RequestMethod.GET)
	public String showAddDepartmentForm(Map<String, Object> map) {
		

		return "AddDepartment";
	}

	@RequestMapping(value = "/addDepartment", method = RequestMethod.GET)
	public String processAddDepartmentForm(DepartmentModel dept, Map<String, Object> map) {
		// Check if department already exists
		if (deptService.isDepartmentExists(dept.getDept_Name())) {
			map.put("msg", "This department already exists!");
		} else {
			// Try to add the department
			boolean b = deptService.isAddDepartment(dept);
			if (b) {
				map.put("msg", "Department added successfully.");
			} else {
				map.put("msg", "Department not added.");
			}
		}
		return "AddDepartment";
	}

	// Mapping for viewing all departments
	@RequestMapping(value = "/viewDepartments", method = RequestMethod.GET)
	public String viewAllDepartments(Map<String, Object> map) {
		List<DepartmentModel> departments = deptService.getAllDepartment();
		map.put("deptlist", departments);
		return "ViewDepartment";
	}

	public List<DepartmentModel> getAllDepartment() {
		List<DepartmentModel> list = deptService.getAllDepartment();

		System.out.println(list);
		return list;
	}

	@RequestMapping("/deleteById")
	public String deletedepartmentByID(@RequestParam("Dept_id") Integer Dept_id, Map map) {
		// int deptid=Integer.parseInt(request.getParameter("Dept_id"));
		deptService.isDeleteDepartmentByID(Dept_id);
		map.put("deptlist", this.getAllDepartment());
		return "ViewDepartment";
	}

	@RequestMapping("/update")
	public String callUpdatepage(@RequestParam("dept_id") Integer dept_id, @RequestParam("dept_name") String dept_name,
			@RequestParam("dept_hod") String dept_hod, Map map) {
		DepartmentModel model = new DepartmentModel();
		model.setDept_id(dept_id);
		model.setDept_Name(dept_name);
		model.setDept_HOD(dept_hod);
		map.put("data", model);
		return "Update";
	}

	@RequestMapping("/updatebyID")
	public String updatebyid(DepartmentModel model, Map map) {

		boolean b = deptService.isupdatebyid(model);
		List<DepartmentModel> list = deptService.getAllDepartment();
		map.put("deptlist", list);
		return "ViewDepartment";
	}

	@RequestMapping(value = "/viewDepartmentwiseAlumni", method = RequestMethod.GET)
	public String viewDepartmentwiseAlumin(Map<String, Object> map) 
	{
		List<DepartmentModel> departments = deptService.getAllDepartment();
		map.put("deptlist", departments);
		return "DepartmentwiseAlumni";
	}

	@RequestMapping(value = "/searchByCompName", method = RequestMethod.GET)
	public String searchByCompNameURL(@RequestParam("n") String compName, Map map) {
		System.out.println(compName);
		List<DepartmentModel> list = deptService.getAllDepartmentByCompName(compName);
		if (list != null) {
			map.put("deptlist", list);
		} else {
			map.put("msg", "This Department Not Available In Database !");
		}

		return "searchbydept";

	}
}
