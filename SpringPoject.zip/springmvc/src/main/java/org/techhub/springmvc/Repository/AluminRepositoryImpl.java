package org.techhub.springmvc.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.springmvc.Model.AdminModel;
import org.techhub.springmvc.Model.AluminModel;
import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Model.EventsModel;

@Repository("AluminRepo")
public class AluminRepositoryImpl implements AluminRepository {
	@Autowired
	JdbcTemplate template;
  
	List<AluminModel>listAlumin;
	public boolean isAddAlumin(AluminModel model) {
		System.out.println(model.getDept_id());
		String checkDeptSql = "SELECT COUNT(*) FROM department WHERE Dept_ID = ?";
		Integer count = template.queryForObject(checkDeptSql, new Object[] { model.getModel().getDept_id() },
				Integer.class);

		if (count == null || count == 0) {
			System.err.println("Invalid dept_id: " + model.getModel().getDept_id());
			return false;
		}

		String insertSql = "INSERT INTO alumin (first_name, last_name, Address, company, Gender, passing_year, Email_ID, Dept_ID, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int value = template.update(insertSql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, model.getFirst_name());
				ps.setString(2, model.getLast_name());
				ps.setString(3, model.getAddress());
				ps.setString(4, model.getCompany());
				ps.setString(5, model.getGender());
				ps.setString(6, model.getPassing_year());
				ps.setString(7, model.getEmail());
				ps.setInt(8,model.getModel().getDept_id());
				//ps.setInt(8, model.getDept());
				ps.setString(9, model.getUserName());
				ps.setString(10, model.getPassword());
			}
		});

		return value > 0;
	}

	public int getDeptID(String deptname) {
		try {
			Integer deptId = template.queryForObject("select Dept_ID from department where Dept_Name=?",
					new Object[] { deptname }, Integer.class);
			return deptId != null ? deptId : 0;
		} catch (Exception ex) {
			System.out.println("Error is:" + ex);
			return -1;
		}
	}

	@Override
	public List<AluminModel> getAllAlumin() {
		List<AluminModel> list = template.query("select * from alumin", new RowMapper<AluminModel>() {

			@Override

			public AluminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				AluminModel Amodel = new AluminModel();
				Amodel.setAlumin_id(rs.getInt(1));
				Amodel.setFirst_name(rs.getString(2));
				Amodel.setLast_name(rs.getString(3));
				Amodel.setAddress(rs.getString(4));
				Amodel.setCompany(rs.getString(5));
				Amodel.setGender(rs.getString(6));
				Amodel.setPassing_year(rs.getString(7));
				Amodel.setEmail(rs.getString(8));
				Amodel.setDept(rs.getInt(9));
				// Amodel.setde(rs.getString(9));
				Amodel.setUserName(rs.getString(10));
				Amodel.setPassword(rs.getString(11));

				return Amodel;
			}

		});

		return list.size() > 0 ? list : null;

	}

	@Override
	public void DeleteAlumin(int al_id) {
		template.update("delete from alumin where Alumin_id=" + al_id);

	}

	@Override
	public boolean isUserLogin(String username, String password) {

		try {
			return template.queryForObject("select* from alumin where username=? and password=?",
					new Object[] { username, password }, new RowMapper<Boolean>() {

						@Override
						public Boolean mapRow(ResultSet rs, int rowNum) throws SQLException {
							AluminModel alumniModel = new AluminModel();
							alumniModel.setUserName(rs.getString("userName"));
							alumniModel.setPassword(rs.getString("password"));
							return true;
						}

					});

		} catch (Exception e) {
			System.out.println("Error is: " + e);
			return false;
		}
	}

	@Override
	public List<AluminModel> getAluminWithMinPassingYear() {
		// String sql = "SELECT * FROM Alumin WHERE passing_year = (SELECT
		// MIN(passing_year) FROM Alumin)";

		return template.query("SELECT * FROM alumin WHERE passing_year=(SELECT MIN(passing_year) FROM alumin)",
				new RowMapper<AluminModel>() {
					@Override
					public AluminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
						AluminModel alumin = new AluminModel();
						alumin.setAlumin_id(rs.getInt("Alumin_id"));
						alumin.setFirst_name(rs.getString("first_name"));
						alumin.setLast_name(rs.getString("last_name"));
						alumin.setEmail(rs.getString("Email_ID"));
						// alumin.setEmail(rs.getString("email"));
						alumin.setAddress(rs.getString("Address"));
						alumin.setCompany(rs.getString("company"));
						alumin.setUserName(rs.getString("username"));
						alumin.setPassword(rs.getString("password"));
						alumin.setPassing_year(rs.getString("passing_year"));
						alumin.setGender(rs.getString("Gender"));
						alumin.setDept(rs.getInt("Dept_ID"));
						// Handle DepartmentModel if needed
						return alumin;
					}
				});
	}

	@Override
	public List<EventsModel> findUpcomingEvents() {
		return template.query(
				"SELECT e.Event_Name, e.date, e.Event_Time, e.Event_Location, d.Dept_Name FROM events e INNER JOIN department d ON e.Dept_ID = d.Dept_ID WHERE e.date >= CURDATE() ORDER BY e.date ASC",
				new RowMapper<EventsModel>() {

					@Override
					public EventsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
						EventsModel event = new EventsModel();
//	            event.setEvent_ID(rs.getInt("Event_ID"));
						event.setEvent_Name(rs.getString("Event_Name"));
						event.setDate(rs.getString("date"));
						event.setTime(rs.getString("Event_Time"));
						event.setEvent_location(rs.getString("Event_Location"));

						DepartmentModel department = new DepartmentModel();
						department.setDept_Name(rs.getString("Dept_Name"));
						event.setDmodel(department);

						return event;
					}

				});
	}

	@Override
	public AluminModel getAluminProfile(String userName) {
		List<AluminModel> alList = template.query("SELECT * FROM alumin WHERE username=?", new Object[] { userName },
				new RowMapper<AluminModel>() {
					public AluminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
						AluminModel alum = new AluminModel();
						alum.setAlumin_id(rs.getInt("Alumin_id"));
						alum.setFirst_name(rs.getString("first_name"));
						alum.setLast_name(rs.getString("last_name"));
						alum.setEmail(rs.getString("Email_ID"));
						alum.setAddress(rs.getString("Address"));
						alum.setCompany(rs.getString("company"));
						alum.setUserName(rs.getString("username"));
						alum.setPassword(rs.getString("password"));
						alum.setPassing_year(rs.getString("passing_year"));
						alum.setGender(rs.getString("Gender"));

						// Setting the DepartmentModel instead of just dept ID
						DepartmentModel department = new DepartmentModel();
						department.setDept_id(rs.getInt("Dept_ID")); // Assuming Dept_ID is the ID field for Department
						alum.setModel(department);

						return alum;
					}
				});
		// Optional: Use proper logging instead of print
		if (alList.isEmpty()) {
			System.out.println("No alumni found with username: " + userName);
		} else {
			System.out.println("Alumni found: " + alList.get(0));
		}

		return alList.isEmpty() ? null : alList.get(0);
	}

	
	  @Override public boolean updateprofile(AluminModel alumin) {
	  int value=template.
	  update("UPDATE alumin SET first_name = ?, last_name = ?, Email_ID = ?, Address = ?, company = ?, username = ?, password = ?, passing_year = ?, Gender = ?, Dept_ID = ? WHERE Alumin_id = ?"
	  , new PreparedStatementSetter() {
	  
	  @Override public void setValues(PreparedStatement ps) throws SQLException {
	  ps.setString(1,alumin.getFirst_name());
	  ps.setString(2,alumin.getLast_name()); ps.setString(3,alumin.getEmail());
	  ps.setString(4,alumin.getAddress()); ps.setString(5,alumin.getCompany());
	  ps.setString(6,alumin.getUserName()); ps.setString(7,alumin.getPassword());
	  ps.setString(8,alumin.getPassing_year()); ps.setString(9,alumin.getGender());
	  ps.setInt(10,alumin.getModel().getDept_id());
	  ps.setInt(11,alumin.getAlumin_id());
	  
	  }
	  
	  });
	  
	  
	  return value>0?true:false; }
	 

	@Override
	public AluminModel getAluminById(Integer aluminId) {
	    try {
	        // SQL query to fetch the alumni by id
	        String query = "SELECT * FROM Alumin WHERE aluminId = ?";

	        // Use JdbcTemplate to query and map the result to an AluminModel object
	        AluminModel alumin = template.queryForObject(query, new Object[] { aluminId }, (rs, rowNum) -> {
	            AluminModel model = new AluminModel();
	            model.setAlumin_id(rs.getInt("aluminId"));
	            model.setFirst_name(rs.getString("first_name"));
	            model.setLast_name(rs.getString("last_name"));
	            model.setAddress(rs.getString("address"));
	            model.setCompany(rs.getString("company"));
	            model.setGender(rs.getString("gender"));
	            model.setPassing_year(rs.getString("passing_year"));
	            model.setEmail(rs.getString("email"));
	            model.setUserName(rs.getString("userName"));
	            model.setPassword(rs.getString("password"));

	            // Assuming you have a DepartmentModel, map it accordingly
	            DepartmentModel department = new DepartmentModel();
	            department.setDept_id(rs.getInt("Dept_ID"));  // Ensure correct column name
	            department.setDept_Name(rs.getString("Dept_Name"));  // Ensure correct column name

	            model.setModel(department);  // Set the department in the alumni model
	            return model;
	        });

	        return alumin;  // Return the fetched AluminModel
	    } catch (Exception ex) {
	        // Log or print the exception message
	        System.out.println("Error fetching alumni by ID: " + ex.getMessage());
	        return null;  // Return null if the alumni is not found or any error occurs
	    }
	}

	
	@Override 
	public boolean updateAlumin(AluminModel alumin) { 
	    int value = template.update("UPDATE alumin SET first_name = ?, last_name = ?, Email_ID = ?, Address = ?, company = ?, password = ?, passing_year = ?, Gender = ? WHERE username = ?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            ps.setString(1, alumin.getFirst_name());
	            ps.setString(2, alumin.getLast_name());
	            ps.setString(3, alumin.getEmail());
	            ps.setString(4, alumin.getAddress());
	            ps.setString(5, alumin.getCompany());
	            ps.setString(6, alumin.getPassword());
	            ps.setString(7, alumin.getPassing_year());
	            ps.setString(8, alumin.getGender());
				/* ps.setInt(9, alumin.getModel().getDept_id()); */
	            ps.setString(9, alumin.getUserName());  // Use username from session
	        }
	    });
	    return value > 0;
	}


	@Override
	public List<AluminModel> getAllCompanyByName(String name) {
		System.out.println("repo"+name);
		listAlumin = template.query("select * from alumin where company like '%"+name+"%'",new RowMapper<AluminModel>() {

			@Override
			public AluminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				AluminModel Amodel = new AluminModel();
				Amodel.setAlumin_id(rs.getInt(1));
				Amodel.setFirst_name(rs.getString(2));
				Amodel.setLast_name(rs.getString(3));
				Amodel.setAddress(rs.getString(4));
				Amodel.setCompany(rs.getString(5));
				Amodel.setGender(rs.getString(6));
				Amodel.setPassing_year(rs.getString(7));
				Amodel.setEmail(rs.getString(8));
				Amodel.setDept(rs.getInt(9));
				// Amodel.setde(rs.getString(9));
				Amodel.setUserName(rs.getString(10));
				Amodel.setPassword(rs.getString(11));
				return Amodel;
			}
	
		});
//		for(AluminModel clist:listAlumin)
//		{
//			System.out.println(clist.getDept_id());
//		}
		return listAlumin.size()>0?listAlumin:null;
		
	}

	@Override
	public List<AluminModel> getAllGender(String gender) {
		
		System.out.println("repo"+gender);
		listAlumin = template.query("select * from alumin where Gender like '%"+gender+"%'",new RowMapper<AluminModel>() {

			@Override
			public AluminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				AluminModel Amodel = new AluminModel();
				Amodel.setAlumin_id(rs.getInt(1));
				Amodel.setFirst_name(rs.getString(2));
				Amodel.setLast_name(rs.getString(3));
				Amodel.setAddress(rs.getString(4));
				Amodel.setCompany(rs.getString(5));
				Amodel.setGender(rs.getString(6));
				Amodel.setPassing_year(rs.getString(7));
				Amodel.setEmail(rs.getString(8));
				Amodel.setDept(rs.getInt(9));
				// Amodel.setde(rs.getString(9));
				Amodel.setUserName(rs.getString(10));
				Amodel.setPassword(rs.getString(11));
				return Amodel;
			}
	
		});
//		for(AluminModel clist:listAlumin)
//		{
//			System.out.println(clist.getDept_id());
//		}
		return listAlumin.size()>0?listAlumin:null;
		
	}

	@Override
	public List<AluminModel> getAllYear(String year) {
		
		System.out.println("repo"+year);
		listAlumin = template.query("select * from alumin where passing_year like '%"+year+"%'",new RowMapper<AluminModel>() {

			@Override
			public AluminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				AluminModel Amodel = new AluminModel();
				Amodel.setAlumin_id(rs.getInt(1));
				Amodel.setFirst_name(rs.getString(2));
				Amodel.setLast_name(rs.getString(3));
				Amodel.setAddress(rs.getString(4));
				Amodel.setCompany(rs.getString(5));
				Amodel.setGender(rs.getString(6));
				Amodel.setPassing_year(rs.getString(7));
				Amodel.setEmail(rs.getString(8));
				Amodel.setDept(rs.getInt(9));
				// Amodel.setde(rs.getString(9));
				Amodel.setUserName(rs.getString(10));
				Amodel.setPassword(rs.getString(11));
				return Amodel;
			}
	
		});
//		for(AluminModel clist:listAlumin)
//		{
//			System.out.println(clist.getDept_id());
//		}
		return listAlumin.size()>0?listAlumin:null;
		
	}
	
	


	

}
