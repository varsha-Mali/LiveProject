package org.techhub.springmvc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.techhub.springmvc.Model.DepartmentModel;
import org.techhub.springmvc.Model.EventsModel;
import org.techhub.springmvc.Repository.EventRepository;

@Service("EventServ")
public class EventServiceImpl implements EventService {
	@Autowired
	EventRepository EventRepo;

	@Override
	public boolean isAddEvents(EventsModel model) {
		return EventRepo.isAddEvents(model);
	}

	@Override
	public int getDeptID(String deptname) {
		return EventRepo.getDeptID(deptname);
	}

	@Override
	public List<EventsModel> getAllEvents() {

		return EventRepo.getAllEvents();
	}

	@Override
	public void isDeleteEventByID(int event_id) {

		EventRepo.isDeleteEventByID(event_id);
	}

	@Override
	public boolean isupdate(EventsModel model) {

		return EventRepo.isupdate(model);
	}

}
