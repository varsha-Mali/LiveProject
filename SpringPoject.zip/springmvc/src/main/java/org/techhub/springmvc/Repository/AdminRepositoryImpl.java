package org.techhub.springmvc.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.springmvc.Model.AdminModel;

@Repository("regRepo")
public class AdminRepositoryImpl implements AdminRepository {

	@Autowired
	JdbcTemplate template;

	@Override
	public boolean isValidate(AdminModel model) {
		// PreparedStatementSetter for setting the parameters in the query
		PreparedStatementSetter stmt = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, model.getUsername());
				ps.setString(2, model.getPassword());
			}
		};

		// RowMapper for mapping the result set to the AdminModel object
		RowMapper<AdminModel> r = new RowMapper<AdminModel>() {
			@Override
			public AdminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				AdminModel model = new AdminModel();
				model.setUsername(rs.getString("Username"));
				model.setPassword(rs.getString("Password"));
				return model;

			}
		};

		// Executing the query
		List<AdminModel> list = template.query("SELECT * FROM admin_login WHERE Username=? AND Password=?", stmt, r);
		
		return list.size() > 0 ? true : false;
	}

	 public AdminModel getAdminInfoByUsername(String username) {
	        // Define the SQL query
	        String sql = "SELECT * FROM admin_login WHERE Username=?";

	        // Using RowMapper to map the ResultSet to AdminModel
	        RowMapper<AdminModel> rowMapper = new RowMapper<AdminModel>() {
	            @Override
	            public AdminModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	                AdminModel model = new AdminModel();
	                model.setLogin_ID(rs.getInt("Login_ID"));
	                model.setUsername(rs.getString("Username"));
	                model.setPassword(rs.getString("Password"));
	                return model;
	            }
	        };

	        // Query the database and return the result
	        List<AdminModel> adminList = template.query(sql, new Object[] {username}, rowMapper);

	        // Return the first result if available, otherwise return null
	        return adminList.isEmpty() ? null : adminList.get(0);
	    }
	
	

}
