package org.techhub.springmvc.Model;
public class EventsModel extends DepartmentModel
{
	    private int Event_ID;
	    private String Event_Name;
	    private DepartmentModel Dmodel;
	    private String date;
	    private String Event_location;
	    private String Time;
	    private int ddid;
	    
		public String getTime() {
			return Time;
		}
		public void setTime(String time) {
			Time = time;
		}
		@Override
		public String toString() {
			return "EventsModel [Event_ID=" + Event_ID + ", Event_Name=" + Event_Name + ", Dmodel=" + Dmodel + ", date="
					+ date + ", Event_location=" + Event_location + ", Time=" + Time + ", ddid=" + ddid + "]";
		}
		public String getEvent_location() {
			return Event_location;
		}
		public int getDdid() {
			return ddid;
		}
		public void setDdid(int ddid) {
			this.ddid = ddid;
		}
		public void setEvent_location(String event_location) {
			Event_location = event_location;
		}
		public int getEvent_ID() {
			return Event_ID;
		}
		public void setEvent_ID(int event_ID) {
			Event_ID = event_ID;
		}
		public String getEvent_Name() {
			return Event_Name;
		}
		public void setEvent_Name(String event_Name) {
			Event_Name = event_Name;
		}
		public DepartmentModel getDmodel() {
			return Dmodel;
		}
		public void setDmodel(DepartmentModel dmodel) {
			Dmodel = dmodel;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		
}
