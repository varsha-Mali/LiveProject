
package org.techhub.springmvc.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.techhub.springmvc.Model.AdminModel;
import org.techhub.springmvc.Model.AluminModel;
import org.techhub.springmvc.Service.AdminService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {

	@Autowired
	AdminService service;

	@RequestMapping("/")
	public String getIndexPage() {
		return "index";
	}
	@RequestMapping("/home")
	public String getHomePage() {
		return "index";
	}
	@RequestMapping("/About")
	public String getAboutPage() {
		return "Aboutus";
	}
    
	@RequestMapping("/contact")
	public String getContactPage() {
		return "Contact us";
	}
	@RequestMapping("/Gallery")
	public String getGalleryPage() {
		return "Gallery";
	}
	
	@RequestMapping(value = "/Admin", method = RequestMethod.GET)
	public String callAdminLoginPage() {
		return "AdminLogin";
	}

	@RequestMapping(value = "/AdminDash", method = RequestMethod.GET)
	public String admin(AdminModel adminModel, Map map) {
		//System.out.println(adminModel);
		boolean amModel = service.isValidate(adminModel);
		//System.out.println(amModel);
		if (amModel) {
			map.put("msg", "Admin Login Successfully...");

			return "AdminLoginDash";
		} else {
			map.put("msg", "Login Failed");
			return "index";
		}

	}

	@RequestMapping(value = "/Profile", method = RequestMethod.GET)
	public String showProfile(HttpSession session, Map<String, Object> map) {
	    // Retrieve the username from the session
	    String username = (String) session.getAttribute("Username");

	    if (username != null) {
	        // Fetch admin details using the username
	        AdminModel admin = service.getAdminInfoByUsername(username);

	        if (admin != null) {
	            // Pass the admin details to the JSP page
	            map.put("admin", admin);
	            return "AdminProfile"; // Return the profile JSP page
	        } else {
	            // In case no admin details are found for the username
	            map.put("error", "No admin found for the given username.");
	            return "AdminProfile"; // You can return a profile page with an error message
	        }
	    } else {
	        // If the session does not have the Username attribute, redirect to the login page
	        return "redirect:/login"; // Redirect to login page if no session found
	    }
	}


	
	
	
	
}
